package com.rh.struts.service;

import com.rh.struts.forms.UserForm;
  
public interface UserManager {  
  
    public void regUser(UserForm user);  
  
}  